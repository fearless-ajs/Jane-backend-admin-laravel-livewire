@extends('layouts.company.app')


@section('content')
    <div class="content-body">
        <!-- Dashboard Ecommerce Starts -->

        @livewire('company-dashboard')

        <!-- Dashboard Ecommerce ends -->

    </div>
@endsection
