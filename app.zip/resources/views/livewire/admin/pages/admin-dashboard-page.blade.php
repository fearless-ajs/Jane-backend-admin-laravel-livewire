@extends('layouts.admin.app')


@section('content')
    <div class="content-body">
        @livewire('admin-dashboard')
    </div>
@endsection
