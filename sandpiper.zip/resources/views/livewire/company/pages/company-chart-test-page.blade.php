@extends('layouts.company.app')


@section('content')
    <div class="content-body">

        @livewire('chart-test')

    </div>
@endsection
'/ ;
