@extends('layouts.contact.app')


@section('content')
    <div class="content-body">
        @livewire('contact-dashboard')
    </div>
@endsection
