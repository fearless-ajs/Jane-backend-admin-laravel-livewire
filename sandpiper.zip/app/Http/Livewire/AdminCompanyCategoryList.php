<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AdminCompanyCategoryList extends Component
{
    public function render()
    {
        return view('livewire.admin-company-category-list');
    }
}
