<div>
    <div class="content-detached content-right">
        <div class="content-body">


            <!-- E-commerce Content Section Starts -->
            <section id="ecommerce-header">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="ecommerce-header-items">
                            <div class="result-toggler">
                                <button class="navbar-toggler shop-sidebar-toggler" type="button" data-bs-toggle="collapse">
                                    <span class="navbar-toggler-icon d-block d-lg-none"><i data-feather="menu"></i></span>
                                </button>
                                <div class="search-results">
                                    <h6 wire:loading.remove wire:target="search" class="filter-heading">@if($searchResult)  {{count($searchResult)}}  @else {{count($company->services)}} @endif results found</h6>
                                    <h6 wire:loading wire:target="search" class="filter-heading">Searching... <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></h6>
                                </div>
                            </div>
                            <div class="view-options d-flex">
                                <div class="btn-group" role="group">
                                    <input type="radio" class="btn-check" name="radio_options" id="radio_option1" autocomplete="off" checked />
                                    <label class="btn btn-icon btn-outline-primary view-btn grid-view-btn" for="radio_option1"><i data-feather="grid" class="font-medium-3"></i></label>
                                    <input type="radio" class="btn-check" name="radio_options" id="radio_option2" autocomplete="off" />
                                    <label class="btn btn-icon btn-outline-primary view-btn list-view-btn" for="radio_option2"><i data-feather="list" class="font-medium-3"></i></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- E-commerce Content Section Starts -->

            <!-- background Overlay when sidebar is shown  starts-->
            <div class="body-content-overlay"></div>
            <!-- background Overlay when sidebar is shown  ends-->

            <!-- E-commerce Search Bar Starts -->
            <section id="ecommerce-searchbar" class="ecommerce-searchbar">
                <div class="row mt-1">
                    <div class="col-sm-12">
                        <div class="input-group input-group-merge">
                            <input type="text" wire:model="search" class="form-control search-product" id="shop-search" placeholder="Search Service" aria-label="Search..." aria-describedby="shop-search" />
                            <span class="input-group-text"><i data-feather="search" class="text-muted"></i></span>
                        </div>
                    </div>
                </div>
            </section>
            <!-- E-commerce Search Bar Ends -->

            <!-- E-commerce Products Starts -->
            <section id="ecommerce-products" class="grid-view">

                @if($services)
                    @foreach($services as $service)
                        <div class="card ecommerce-card mb-2">
                            {{--                            <div class="item-img text-center">--}}
                            {{--                                <a href="app-ecommerce-details.html">--}}
                            {{--                                    <img class="img-fluid card-img-top" src="{{$service->serviceImage}}" alt="img-placeholder" /></a>--}}
                            {{--                            </div>--}}
                            <div class="card-body">
                                <div class="item-wrapper">
                                    <div class="item-rating">
                                        <ul class="unstyled-list list-inline">
                                            <span class="badge badge-light-success">{{$service->usage_unit}} </span>
                                        </ul>
                                    </div>
                                    <div>
                                        <h6 class="item-price">{{$settings->app_currency_symbol}}{{$service->price}}</h6>
                                    </div>
                                </div>
                                <h6 class="item-name">
                                    <a class="text-body" href="#">{{$service->name}}</a>
                                    <span class="card-text item-company">By <a href="#" class="company-name">{{$service->manufacturer}}</a></span>
                                </h6>
                                <p class="card-text item-description">
                                    {{$service->description}}
                                </p>
                            </div>
                            <div class="item-options text-center mb-2">
                                <div class="item-wrapper">

                                    <div class="item-cost">
                                        <h4 class="item-price">{{$settings->app_currency_symbol}} {{$service->price}}</h4>
                                    </div>
                                </div>
                                <a href="{{route('admin.company-service-details', $service->id)}}" class="btn btn-light btn-wishlist">
                                    <span>See details</span>
                                </a>
                            </div>
                        </div>
                    @endforeach
                @endif


            </section>
            <!-- E-commerce Products Ends -->

            <!-- E-commerce Pagination Starts -->
            <section id="ecommerce-pagination">
                <div class="row">
                    <div class="col-sm-12">
                        @if(!$searchResult)
                            {{ $services->links('components.general.pagination-links') /* For pagination links */}}
                        @endif
                    </div>
                </div>
            </section>
            <!-- E-commerce Pagination Ends -->

        </div>
    </div>


</div>
